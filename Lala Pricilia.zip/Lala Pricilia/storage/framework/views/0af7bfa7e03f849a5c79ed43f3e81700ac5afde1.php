

<?php $__env->startSection('content'); ?>
<div class="container" style="padding-top: 40px;min-height: 550px">
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <p class="card-text">
                        <div class="card-title">
                            <h5>Data Pelanggan</h5>
                        </div>
                        <a href="<?php echo e(route('customer.create')); ?>">
                            <button class="btn btn-sm btn-success">Tambah</button>
                        </a>
                        <p></p>
                        <table class="table table-stripped">
                            <tr>
                                <th>Nama</th>
                                <th>Aksi</th>
                            </tr>
                            <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->name); ?></td>
                                <td style="width: 25%">
                                <a href="<?php echo e(route('customer.edit', $item->id)); ?>">
                                    <button class="btn btn-sm btn-warning">Edit</button>
                                </a>
                                <form action="<?php echo e(route('customer')); ?>" method="POST" style="display: inline">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <input type="text" name="id" value="<?php echo e($item->id); ?>" style="display:none">
                                    <button class="btn btn-sm btn-danger" name="hapus">Hapus</button>
                                </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </p>
                </div>
            </div>
        </div>
    </div>
   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Lala Pricilia\resources\views/apps/customer/index.blade.php ENDPATH**/ ?>