

<?php $__env->startSection('content'); ?>
<div class="container" style="padding-top: 40px; min-height: 550px">
    <div class="col-md-12">
        <div class="card text-left" style="width: 600px">
        <img class="card-img-top" src="holder.js/100px180/" alt="">
        <div class="card-body">
            <h4 class="card-title">Data Menu</h4>
            <p class="card-text">
                <form action="<?php echo e(route('menu')); ?>" method="POST">
                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                    <input type="hidden" name="id" value="<?php echo e($menu->id); ?>">
                    <div class="form-group">
                      <label for="">Nama</label>
                      <input type="text" class="form-control" name="name" value="<?php echo e($menu->name); ?>">
                    </div>
                    <div class="form-group">
                        <label for="">Harga</label>
                        <input type="text" class="form-control" name="price" value="<?php echo e($menu->price); ?>">
                      </div>
                    <div class="d-flex justify-content-end mt-4">
                        <button class="btn btn-sm btn-success" name="simpan">Simpan</button>
                    </div>
                </form>
            </p>
        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Lala Pricilia\resources\views/apps/menu/edit.blade.php ENDPATH**/ ?>