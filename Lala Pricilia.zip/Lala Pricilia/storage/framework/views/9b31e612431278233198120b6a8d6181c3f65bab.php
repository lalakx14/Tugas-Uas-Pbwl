

<?php $__env->startSection('content'); ?>
<div class="container" style="padding-top: 40px; padding-bottom: 40px; min-height: 600px">
    <div class="card" style="width: 600px">
        <div class="card-body">
            <div class="card-title"><h5>Data Pelanggan</h5></div>
            <p class="card-text">
            <form action="<?php echo e(route('customer')); ?>" method="POST">
                <?php echo csrf_field(); ?> <?php echo method_field('POST'); ?>
                <div class="form-group mt-2 mt-2">
                    <label for="">Nama</label>
                    <input type="text" name="name" class="form-control">
                </div>
                <div class="d-flex justify-content-end mt-4">
                    <button class="btn btn-sm btn-success" name="simpan">Simpan</button>
                </div>
            </form>
            </p>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Lala Pricilia\resources\views/apps/customer/create.blade.php ENDPATH**/ ?>