

<?php $__env->startSection('content'); ?>
<div class="container" style="padding-top: 40px; padding-bottom: 40px; min-height: 600px">
    <div class="card" style="width: 600px">
        <div class="card-body">
            <div class="card-title"><h5>Data Detail Transaksi</h5></div>
            <p class="card-text">
            <form action="<?php echo e(route('transaction_detail')); ?>" method="POST">
                <?php echo csrf_field(); ?> <?php echo method_field('POST'); ?>
                <div class="form-group mt-2 mt-2">
                    <label for="">Transaksi</label>
                    <select name="transaction_id" id="" class="form-control">
                        <option value="">-Silahkan Pilih-</option>
                        <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->customer->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div> 
                <div class="form-group mt-2 mt-2">
                    <label for="">Menu</label>
                    <select name="menu_id" id="" class="form-control">
                        <option value="">-Silahkan Pilih-</option>
                        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?> | <?php echo e($item->price); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div> 
                <div class="form-group mt-2 mt-2">
                    <label for="">Jumlah</label>
                    <input type="number" name="total" class="form-control" value="">
                </div> 
                <div class="d-flex justify-content-end mt-4">
                    <button class="btn btn-sm btn-success" name="simpan">Simpan</button>
                </div>
            </form>
            </p>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Lala Pricilia\resources\views/apps/transaction_detail/create.blade.php ENDPATH**/ ?>